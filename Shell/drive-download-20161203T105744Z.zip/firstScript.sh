#!/bin/sh
#The above comment lets the shell know that the file your calling is a shell script
#eliminating the need for the exectuable to be preceded by 'sh'

name = beans

echo $name is tasty
echo we always have to precede a variable with a dollar sign when using it

#single quotes means escape all special meaning of the characters inside
#double quotes means escape most special meaning of the chracters inside
echo '$'name will not use the variable, it escapes the special meaning


#the conditions in shell scripting work via commands, if the command successfully
#ececutes then the 'condition' is met
#we could make the date command fail by giving it an invalid argument
if date > /dev/null
then
    echo the date execution worked
else
    echo the date execution did not work
fi

#the test command is satisfied when the specified file is in the current dir
while test *
do
    echo keep running this 'while' there exists a file 'in' the current dir
    #pause processing for 2 seconds
    sleep 2
done

#increasing i but stop at 10
i = 0
while test $i -lt 10
do
    echo $i
    i = `expr $i + 1`
done

#$1 means the first argument given to the shell file in the terminal
#$2 means the second argument
#-ne means not equal to
#$# means number of arguments
if test $# -ne 3
then
    echo there were not three arguments passed 'in'
start = $1
finish = $2
step = $3
i = $start
while test $i -lt $finish
do
    echo $i
    i = `expr $i + $step`
done
