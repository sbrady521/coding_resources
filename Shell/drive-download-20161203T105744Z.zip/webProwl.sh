#!/bin/sh

#wget -O - [url] sends the contents of a webpage to stdout
#curl [url] does the same


#this script continuously analyses a site and alerts us if the site changes
curl http://127.0.0.1/ > output.txt  > 2>/dev/null
while true
do
    curl http://127.0.0.1/ > output.txt > 2>/dev/null
    if egrep -i '(taylor|Tailor).*swift' output.txt
    then
        echo TAYLOR SWIFT TECKETS ON SALE
    else
        echo -n .
    sleep 1
done
