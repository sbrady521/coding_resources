#!/bin/sh

for file1 in "$@"
do
    for file2 in "$@"
    do
        #remove all lines begining with a # from the files
        sed 's/\/\/.* s/[_a-zA-z][_a-zA-Z0-9]/andrew/g' $file1 > tmp1
        sed 's/\/\/.*' $file2 > tmp2
        #if the files have the same name then skip this iteration
        #[do something] || exit - would ensure that the somethin was successful, or else the program exits
        test "$file1" = "$file2" && continue
        #the -i flag for dif means ignore
        #iwB means ignore blank lines and white space
        if diff -iBw $tmp1 $tmp2 >/dev/null
        then
            echo $file1 $file2 may be plagairism
        fi
    done
done
