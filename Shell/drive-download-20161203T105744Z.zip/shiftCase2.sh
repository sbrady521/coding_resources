#!bin/sh

for uc_filename in *
do
    lc_filename=`echo "$uc_filename"|tr A-Z a-Z`
    #it is important to always put double quotations around variables, in case they contain spaces in the variable
    if test "$lc_filename" = "$uc_filename"
    then
        continue
    fi
    #test -e tests to see if a file exists
    if test -e "$lc_filename"
    then
        echo "$lc_filename" already exists
        continue
    fi
    mv "$uc_filename" "$lc_filename"
