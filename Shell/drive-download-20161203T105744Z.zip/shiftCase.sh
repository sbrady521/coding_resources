#!/bin/sh

for upperCase in *
do
    lowerCase = `echo $upperCase | tr A-Z a-z`
    if test $lowerCase = $upperCase
    then
        continue
    if cp $upperCase $lowerCase
    then
        rm $upperCase
    fi
done
